
                                       X-Killer Information 
                                       --------------------

                                    Last changed on 12-01-2000

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 REGISTRATION
 ------------
 X-Killer is now shareware .. what the f*ck does that mean ?
 !! IT MEANS THAT YOU CAN USE THIS PROGRAM 30 DAYS FOR FREE ...
 !! IF YOU USE IT ANY LONGER, YOU WILL NEED TO REGISTER IT
 
 Why should I register and pay for something I already have and is fully functional ?
  - the shareware message & 10 sec delay will be removed
  - the main window will show 'Registered to : xxx' instead of 'UNREGISTERED VERSION'
  - there could be future functions that require a registered version to work

 What is it going to cost me ?
  - You can (more or less) decide yourself how much you want to pay me -> minimal 100BEF / 3US$

 How can I register ?
  - Put the money (minimal 100BEF/3US$) in an envelope and send it to :  Tim Schuerewegen
                                                                         Du Chastellei 5
                                                                         2170 Merksem
                                                                         BELGIUM
  - After I have recieved the money, I'll e-mail you a regname & regcode to register X-Killer
    which will remove the shareware message & 10 sec delay (it won't remove the first message)
  - Please make sure you wrap the money in some piece of paper so no-one tries to steal it
    If I don't recieve the money... no registration
  
  Please e-mail me the following information after sending the money

    Real name : <full name>
    Nickname  : <nickname>
    Age       : <age>
    Sex       : <male/female>
    Address   : <street, city, province/state, country, continent>
    E-mail    : <e-mail address>
    Money     : <amount of money in envelope>

  BTW, if anyone cracks X-Killer... I'll be forced to stop releasing new versions :(

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 WHAT CAN YOU DO WITH X-KILLER THAT YOU CAN'T DO WITH X-LINK ?
 (or)
 WHAT MAKES X-KILLER SO SPECIAL ?
 -------------------------------------------------------------

 - No territory check when upgrading the ROM
 - Ability to encrypt and decrypt ROM files
 - Backup the ROM without having to upgrade it
 - View information about ROM files in ROM Manager (version/date/...)
 - Extract codes from ROM files
 - No restrictions on viewing and downloading memory
 - Automatically changing PAL<->NTSC on V3/FX ROM's

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 COMPATIBILITY TEST X-KILLER & XPLORER ROM'S
 -------------------------------------------------------

 " + " = it is supposed to work :)
 " ~ " = it works but not on all ROM's
 " - " = it doesn't work (yet)
 " ? " = I don't know if it works or not
 1 = 1.x ROM (V1)
 2 = 2.x ROM (V2/PRO)
 3 = 3.x ROM (V3/PRO/FX)
 4 = X-Flash v0.1
 5 = X-Flash v1.0
 6 = Xplorer64

 /****************************************************\
 | Function                   | 1 | 2 | 3 | 4 | 5 | 6 |
 |*****************************************************
 | VIDEO MODE                 | - | - | + | - | - | - |
 | CODES - BACKUP             | + | + | + | - | + | + |
 | MEMORY EDITOR              | + | + | + | - | + | + |
 | ROM MANAGER                | + | + | + | + | + | + |
 | SPEED TEST                 | + | + | + | + | + | + |
 \****************************************************/

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 HISTORY :
 ---------

 v0.60 - * Removed : memcard manager, code enc/dec, .... (sorry guys)
         * Added   : Auto refresh option in 'Memory Editor'
                     Xplorer64 support
	   X-Killer is now shareware !

 v0.56 - * Fixed : when changing PAL<->NTSC using X-Killer, Xplorer can be killed

 v0.55 - * Added : ROM Manager
                   Support for X-Flash 1.0
                   Dump GPU (3.x ROM only)
                   Video mode (PAL/NTSC) switch (3.x ROM only)
                   Minimize button
                   "Force X-Run" option
                   "Memory" option
                   Automatic ROM recognition (46 PSX FCD ROM's are known)
         * Removed : "X2 Protocol" option

 v0.50 - * Added : Upload memcard image
                   Upload psx-exe's on Xplorer FX
                   "Dump SPU" function
         * Fixed : 101 bugs :)
         * Removed : many options and the minimize button :((
                     "REPAIR" function, "UPGRADE" should work 100% with X-Flash v0.1

 v0.47 - * Added : Missing file required to upgrade XP + caetla 0.34 ROM
                   "REPAIR" function to make ROM upgrades compatible again with X-Flash CD
         * Fixed : Upgrade cancel bug
                   SPEED TEST and V3/FX upload problem

 v0.45 - * SETTINGS - Added : Caetla 0.34 support
         * SPEED TEST - Added
         * MEMCARD MANAGER - Fixed : Bug with 2nd memorycard slot
         * VALIDATE UPGRADE - Fixed : False errors (only full 128-byte blocks will be reported)
         * Other small corrections I can't remember (security/bugs/...)

 v0.39 - * SETTINGS - Added : Validate upgrade
                      Added : Transfer warnings
         * ROM BACKUP - Added : Support for V3 ROM's
         *     DETECT - Added : Display flashrom size (256KB/384KB)
         * PSX UPLOAD EXE - Fixed : 2 stupid bugs which prevented it to work at all

 v0.35 - * CODES DOWNLOAD - Added : Support for FX cartridges
	 * CODES EXTRACT FROM FILE - Added : Support for FX ROM files
         * MEMCARD MANAGER - Fixed : Repeating "[01]" instead of 1-15
                             Fixed : Filesize only 1024 bytes when dumping a memorycard
         * Fixed : Stupid bug regarding 1.x ROM's

 v0.30 - * CODES ENC/DEC - Added : New encryption/decryption routine added (eat this FCD!!)
         * MEMORY EDITOR - Fixed : "prefix" problem ("&" symbol)
                           Fixed : Redraw background to prevent "empty" screen
                           Added : Dump function added (downloads current memory region)
         * Added : Show information about selected ROM file in "open" and "save as" dialog boxes

 v0.26 - * Fix for NT users, X-Killer will work perfectly after "giveio.sys" has been installed

 v0.25 - * CODES ENC/DEC : Ability to enc/dec only the last 2 or 4 bytes of a code
                           They have to be placed between an "<" and ">" character
                           Example : ".... < 00 01 0002 0920 > ...."
                           [feature requested by Snakebite]
         * CODES : "Extract From File" added (doesn't work with FX ROM's)
         * ROM : "Detect" added which reads version/date/language of Xplorer (FX)
         * PSX : "Xplorer Status" removed
         * HELP : "Information" added
         * Main title problem fixed (empty dialog + number)
         * Registry bug on NT systems fixed
                          
 v0.20 - * MEMORY EDITOR : More memory regions
         * MEMORY EDITOR : Download function works
         * SETTINGS :  Enable/disable startup I/O
         * ROM : Support for Xplorer FX (backup, encrypt and decrypt)

 v0.12 - * ROM UPGRADE : Support for incompatible ROM's (ar/gs/caetla)
                         !! X-Flash CD is required !!
         * Faster data transfer on older PC's (XP->PC)

 v0.10 - * First release of X-Killer

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 EXISTING ROM'S
 --------------

 << PLEASE CHECK MY HOMEPAGE FOR AN UP-TO-DATE ROMLIST >>

 Any other ROM's would be greatly appreciated :)
 Before e-mailing any ROM's, please contact me as I may already have it

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 HOW TO CONTACT ME ?
 -------------------

 E-Mail  : Tim.Schuerewegen@village.uunet.be
 Web     : http://www.cherryroms.com/firefly
           (http://gallery.uunet.be/Tim.Schuerewegen)
           (http://members.xoom.com/Schuerewegen)
 eGroup  : http://www.egroups.com/list/x-killer
 Tel     : (032) 03/646.98.35

 If you want to give me money, an Xplorer FX or something else, then send it to :
  
  ********************
  * Tim Schuerewegen *
  * du Chastellei 5  *
  * 2170 Merksem     *
  * BELGIUM          *
  ********************

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 SPECIAL THANKS TO
 -----------------
 
 Snakebite, Hackman, Avid Gamer, Murray Moffatt, Dave Wallace - for sending me ROM's
 Neal, Melonhead - for beta-testing X-Flash
 Blaze / FCD - for sending me the necessary hardware (for free)
 All beta testers :)

 Did I forget you ? Send me an e-mail !

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

             Thank you for reading this document and I hope you will enjoy X-Killer
